# Jordan Griffith — Personal Landing Page

A personal portfolio and landing page built with React, showcasing my background, skills, and experience as a Business Analytics & Information Systems student at the University of Iowa.

**Live site:** [View on Azure](#) *(update with your Azure domain)*

---

## About

Hi, I'm Jordan Griffith — a fourth year Business Analytics & Information Systems student at the University of Iowa. I'm interested in performance improvements, problem-solving, and critical thinking, and I'm open-minded about where a business career can take me.

This site serves as my personal corner of the web, highlighting my academic journey, professional experience, and what makes me tick.

---

## What's on the Page

| Section | Description |
|---|---|
| **Hero** | Introduction, headshot, and quick links to LinkedIn and GitHub |
| **About** | Personal bio, values, and interests |
| **Skills** | Core competencies including Power BI, Microsoft Suite, analytical thinking, and leadership |
| **Experience** | IT Internship (KPI Dashboards via Power BI) and Restaurant & Bar Management |
| **Contact** | Links to LinkedIn and GitHub |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | [React](https://react.dev/) + [Vite](https://vite.dev/) |
| Styling | [Tailwind CSS](https://tailwindcss.com/) |
| Animations | [Framer Motion](https://www.framer.com/motion/) |
| UI Components | [shadcn/ui](https://ui.shadcn.com/) |
| Icons | [Lucide React](https://lucide.dev/) |
| Package Manager | [pnpm](https://pnpm.io/) (monorepo workspace) |
| Hosting | Azure Static Web Apps |

---

## Project Structure

```
artifacts/landing-page/
├── public/
│   └── headshot.png          # Profile photo
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   └── Navbar.tsx    # Sticky navigation bar
│   │   ├── sections/
│   │   │   ├── Hero.tsx      # Hero / introduction section
│   │   │   ├── About.tsx     # About me section
│   │   │   ├── Skills.tsx    # Core competencies section
│   │   │   ├── Experience.tsx # Professional experience section
│   │   │   └── Contact.tsx   # Contact / social links section
│   │   └── ui/               # Reusable UI components
│   ├── pages/
│   │   └── Home.tsx          # Main page composition
│   ├── App.tsx               # App root and routing
│   └── index.css             # Global styles and CSS variables
└── package.json
```

---

## Running Locally

**Prerequisites:** Node.js 18+ and pnpm installed.

```bash
# Clone the repository
git clone https://github.com/jordan-griffith/your-repo-name.git
cd your-repo-name

# Install dependencies
pnpm install

# Start the development server
pnpm --filter @workspace/landing-page run dev
```

The site will be available at `http://localhost:5173` (or the port shown in your terminal).

---

## Deployment

This project is deployed to **Azure Static Web Apps** via a GitHub Actions workflow. Every push to `main` triggers an automatic build and deployment.

To deploy your own copy:

1. Fork this repository
2. Create an Azure Static Web App linked to your GitHub repo
3. Add your Azure deployment token as a GitHub secret
4. Push to `main` — the workflow handles the rest

---

## Connect

- **LinkedIn:** [linkedin.com/in/jordan-griffith1](https://www.linkedin.com/in/jordan-griffith1)
- **GitHub:** [github.com/jordan-griffith](https://github.com/jordan-griffith)

---

*Built with [Replit](https://replit.com)*
