import { motion } from "framer-motion";
import { Github, Linkedin, Mail, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Contact() {
  return (
    <section id="contact" className="py-24 md:py-32 relative overflow-hidden scroll-mt-20">
      <div className="absolute inset-0 bg-foreground text-background -z-20" />
      <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      
      {/* Decorative gradient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-primary/20 blur-[120px] rounded-[100%] -z-10 pointer-events-none" />

      <div className="container-custom relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-center flex flex-col items-center"
        >
          <span className="px-4 py-1.5 rounded-full bg-white/10 text-white text-sm font-medium border border-white/10 mb-8 inline-block">
            Let's Connect
          </span>
          
          <h2 className="text-4xl md:text-6xl font-display font-bold text-white mb-6 leading-tight">
            Ready to build something <span className="text-primary">impactful?</span>
          </h2>
          
          <p className="text-lg md:text-xl text-white/70 mb-12 max-w-2xl leading-relaxed">
            I am currently open to new opportunities where I can apply my analytical skills, 
            passion for problem-solving, and dedication to continuous improvement.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
            <a 
              href="https://www.linkedin.com/in/jordan-griffith1" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full sm:w-auto"
            >
              <Button size="lg" className="w-full sm:w-auto rounded-full h-14 px-8 text-base bg-[#0A66C2] hover:bg-[#0A66C2]/90 text-white border-none">
                <Linkedin className="mr-2 w-5 h-5" />
                Connect on LinkedIn
                <ExternalLink className="ml-2 w-4 h-4 opacity-50" />
              </Button>
            </a>
            <a 
              href="https://github.com/jordan-griffith" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full sm:w-auto"
            >
              <Button size="lg" variant="outline" className="w-full sm:w-auto rounded-full h-14 px-8 text-base bg-white/5 border-white/20 text-white hover:bg-white/10 hover:text-white">
                <Github className="mr-2 w-5 h-5" />
                View GitHub
              </Button>
            </a>
          </div>

        </motion.div>
      </div>

      <div className="absolute bottom-6 inset-x-0 text-center text-white/40 text-sm">
        <p>© {new Date().getFullYear()} Jordan Griffith. All rights reserved.</p>
      </div>
    </section>
  );
}
