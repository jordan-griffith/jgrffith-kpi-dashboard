import { motion } from "framer-motion";
import { Database, Lightbulb, Users, LayoutDashboard, Search, ListChecks, Trophy } from "lucide-react";

const skills = [
  { name: "Collaboration", icon: Users, color: "text-blue-500", bg: "bg-blue-500/10" },
  { name: "Analytical Thinking", icon: Search, color: "text-indigo-500", bg: "bg-indigo-500/10" },
  { name: "Organization", icon: ListChecks, color: "text-emerald-500", bg: "bg-emerald-500/10" },
  { name: "Power BI", icon: LayoutDashboard, color: "text-yellow-600", bg: "bg-yellow-600/10" },
  { name: "Microsoft Suite", icon: Database, color: "text-sky-500", bg: "bg-sky-500/10" },
  { name: "Critical Thinking", icon: Lightbulb, color: "text-amber-500", bg: "bg-amber-500/10" },
  { name: "Problem-Solving", icon: Search, color: "text-rose-500", bg: "bg-rose-500/10" },
  { name: "Leadership", icon: Trophy, color: "text-primary", bg: "bg-primary/10" },
];

export function Skills() {
  return (
    <section id="skills" className="section-padding scroll-mt-20 relative">
      <div className="container-custom">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-display font-bold mb-4"
          >
            Core <span className="text-primary">Competencies</span>
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-muted-foreground text-lg"
          >
            Tools and traits I leverage to transform data into insights and lead teams to success.
          </motion.p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {skills.map((skill, index) => {
            const Icon = skill.icon;
            return (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className="group p-6 bg-card rounded-2xl border border-border shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-300 flex flex-col items-center justify-center text-center gap-4 cursor-default"
              >
                <div className={`w-14 h-14 rounded-full ${skill.bg} ${skill.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-semibold text-foreground">{skill.name}</h3>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
