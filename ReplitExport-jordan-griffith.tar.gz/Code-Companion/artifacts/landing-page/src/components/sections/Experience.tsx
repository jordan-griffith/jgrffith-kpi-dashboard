import { motion } from "framer-motion";
import { Briefcase, BarChart3, Users } from "lucide-react";

const experiences = [
  {
    role: "IT Intern",
    company: "Confidential", // Prompt didn't specify company, keeping it professional
    type: "Internship",
    icon: BarChart3,
    description: "Spearheaded the development and maintenance of KPI Dashboards using Power BI, translating raw data into actionable insights to drive performance improvements and monitor organizational metrics.",
    skills: ["Power BI", "Data Visualization", "KPI Tracking", "Analytics"]
  },
  {
    role: "Restaurant & Bar Manager",
    company: "Hospitality Industry",
    type: "Management",
    icon: Users,
    description: "Developed strong leadership and operational skills by managing staff, coordinating daily operations, and ensuring exceptional customer service in a fast-paced, highly collaborative environment.",
    skills: ["Leadership", "Operations", "Customer Service", "Team Coordination"]
  }
];

export function Experience() {
  return (
    <section id="experience" className="section-padding bg-secondary/30 scroll-mt-20">
      <div className="container-custom">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16"
        >
          <div>
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
              Professional <span className="text-primary">Experience</span>
            </h2>
            <div className="w-20 h-1.5 bg-primary rounded-full" />
          </div>
          <p className="text-muted-foreground text-lg max-w-md">
            My journey through analytics and operational leadership.
          </p>
        </motion.div>

        <div className="relative">
          {/* Vertical Line */}
          <div className="hidden md:block absolute left-8 top-4 bottom-4 w-px bg-border" />

          <div className="space-y-8 md:space-y-12">
            {experiences.map((exp, index) => {
              const Icon = exp.icon;
              return (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  className="relative md:pl-24"
                >
                  {/* Timeline Node */}
                  <div className="hidden md:flex absolute left-4 top-6 w-8 h-8 -translate-x-1/2 rounded-full bg-background border-2 border-primary items-center justify-center z-10 shadow-sm">
                    <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                  </div>

                  <div className="bg-card border border-border/50 rounded-3xl p-6 md:p-8 shadow-md shadow-black/5 hover:shadow-lg hover:border-primary/20 transition-all duration-300">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0 mt-1">
                          <Icon className="w-6 h-6" />
                        </div>
                        <div>
                          <h3 className="text-xl md:text-2xl font-bold text-foreground">{exp.role}</h3>
                          <div className="flex flex-wrap items-center gap-2 mt-2 text-muted-foreground font-medium">
                            <span className="text-foreground">{exp.company}</span>
                            <span className="w-1.5 h-1.5 rounded-full bg-border" />
                            <span>{exp.type}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <p className="text-muted-foreground leading-relaxed text-base md:text-lg mb-6">
                      {exp.description}
                    </p>

                    <div className="flex flex-wrap gap-2">
                      {exp.skills.map((skill) => (
                        <span 
                          key={skill}
                          className="px-3 py-1 bg-secondary text-secondary-foreground text-sm font-medium rounded-lg"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
