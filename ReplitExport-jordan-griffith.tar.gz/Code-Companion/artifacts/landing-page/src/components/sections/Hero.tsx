import { motion } from "framer-motion";
import { ArrowRight, MapPin, Briefcase, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section id="top" className="relative min-h-[100svh] flex items-center pt-24 pb-12 overflow-hidden">
      {/* Abstract Background Elements */}
      <div className="absolute top-1/4 -right-1/4 w-[800px] h-[800px] bg-primary/5 rounded-full blur-[120px] -z-10" />
      <div className="absolute -bottom-1/4 -left-1/4 w-[600px] h-[600px] bg-accent/30 rounded-full blur-[100px] -z-10" />

      <div className="container-custom grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
        
        {/* Left Column: Text Content */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex flex-col gap-6"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium w-fit border border-primary/20">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            Available for new opportunities
          </div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-bold leading-[1.1] text-balance">
            Hi, I'm <span className="text-primary relative inline-block">
              Jordan
              <svg className="absolute -bottom-2 left-0 w-full h-3 text-primary/30" viewBox="0 0 100 10" preserveAspectRatio="none">
                <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="4" fill="transparent" strokeLinecap="round" />
              </svg>
            </span>
            <br />
            Business Analyst
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-xl">
            Business Analytics & Information Systems Student at the University of Iowa, 
            passionate about data-driven problem solving and critical thinking.
          </p>

          <div className="flex flex-wrap items-center gap-4 mt-2">
            <a href="#about">
              <Button size="lg" className="rounded-full group">
                More About Me
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </a>
            <a href="https://www.linkedin.com/in/jordan-griffith1" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="lg" className="rounded-full bg-background/50 backdrop-blur-sm">
                Connect on LinkedIn
              </Button>
            </a>
          </div>

          <div className="flex items-center gap-6 mt-6 text-sm text-muted-foreground font-medium">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              Iowa City, IA
            </div>
            <div className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Student / Analyst
            </div>
          </div>
        </motion.div>

        {/* Right Column: Visual / Avatar */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="relative lg:ml-auto w-full max-w-[480px] aspect-square mx-auto lg:mx-0"
        >
          {/* Decorative frame */}
          <div className="absolute inset-0 rounded-[2.5rem] border border-border/60 bg-gradient-to-tr from-background to-secondary/50 shadow-2xl shadow-black/5 rotate-3 transition-transform duration-500 hover:rotate-0" />
          
          <div className="absolute inset-0 rounded-[2.5rem] overflow-hidden bg-card border border-border/50 flex flex-col items-center justify-center -rotate-3 transition-transform duration-500 hover:rotate-0 group">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] mix-blend-overlay pointer-events-none" />
            
            {/* Headshot */}
            <div className="w-52 h-52 rounded-full shadow-xl shadow-primary/20 mb-8 relative overflow-hidden border-4 border-background/70">
              <img 
                src="/headshot.png" 
                alt="Jordan Griffith" 
                className="w-full h-full object-cover object-top"
              />
            </div>
            
            <div className="text-center px-8 z-10">
              <h3 className="text-2xl font-bold text-foreground">Jordan Griffith</h3>
              <p className="text-primary font-medium mt-1">Aspiring Data Professional</p>
              <div className="flex gap-2 justify-center mt-6">
                <span className="px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-xs font-semibold">Analytical</span>
                <span className="px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-xs font-semibold">Driven</span>
              </div>
            </div>
          </div>
        </motion.div>

      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground"
      >
        <span className="text-xs font-medium uppercase tracking-widest">Scroll</span>
        <ChevronDown className="w-4 h-4 animate-bounce" />
      </motion.div>
    </section>
  );
}
