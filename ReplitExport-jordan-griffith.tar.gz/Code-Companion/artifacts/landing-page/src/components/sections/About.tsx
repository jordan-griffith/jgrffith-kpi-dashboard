import { motion } from "framer-motion";
import { UserCircle, Heart, Coffee, Globe } from "lucide-react";

export function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section id="about" className="section-padding bg-secondary/30 scroll-mt-20">
      <div className="container-custom">
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid lg:grid-cols-[1fr_1.5fr] gap-12 lg:gap-20"
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="flex flex-col gap-4">
            <h2 className="text-3xl md:text-4xl font-display font-bold">
              About <span className="text-primary">Me</span>
            </h2>
            <div className="w-20 h-1.5 bg-primary rounded-full" />
            <p className="text-muted-foreground mt-4 text-lg">
              A blend of technical prowess and interpersonal skills, driven to solve complex business challenges.
            </p>
            
            <div className="mt-8 space-y-4">
              <div className="flex items-center gap-4 text-foreground font-medium">
                <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-border flex items-center justify-center text-primary">
                  <UserCircle className="w-6 h-6" />
                </div>
                Outgoing & Collaborative
              </div>
              <div className="flex items-center gap-4 text-foreground font-medium">
                <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-border flex items-center justify-center text-primary">
                  <Globe className="w-6 h-6" />
                </div>
                Open-Minded Explorer
              </div>
            </div>
          </motion.div>

          {/* Bio Content */}
          <motion.div variants={itemVariants} className="bg-card border border-border/50 rounded-3xl p-8 md:p-10 shadow-lg shadow-black/5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -z-0" />
            
            <div className="relative z-10 space-y-6 text-base md:text-lg text-foreground/80 leading-relaxed">
              <p>
                <strong className="text-foreground">I am a fourth year Business Analytics and Information Systems student</strong> at the University of Iowa. 
                I am interested in performance improvements, problem-solving, and critical thinking, but very open-minded about where all business careers could take me.
              </p>
              <p>
                I have developed strong leadership skills from volunteering and managing a restaurant and bar. I am very outgoing and succeed in collaborative and engaging environments where communication is key.
              </p>
              <div className="pt-6 border-t border-border mt-6">
                <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-4">When I'm not studying or working</h4>
                <ul className="grid sm:grid-cols-2 gap-3">
                  <li className="flex items-center gap-3">
                    <Heart className="w-5 h-5 text-primary" />
                    Spending time with family
                  </li>
                  <li className="flex items-center gap-3">
                    <Coffee className="w-5 h-5 text-primary" />
                    Playing strategic games
                  </li>
                  <li className="flex items-center gap-3">
                    <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Exploring new places
                  </li>
                  <li className="flex items-center gap-3">
                    <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    Exercising & Outdoors
                  </li>
                </ul>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
