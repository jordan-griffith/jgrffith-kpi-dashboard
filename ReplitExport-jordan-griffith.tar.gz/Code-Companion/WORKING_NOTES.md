# Working Notes

## Session Date
March 23, 2026

## Session Goals
Build a personal landing page for Jordan Griffith to serve as a professional online presence, deployable to Azure via GitHub Actions.

---

## Work Completed

### 1. Landing Page Created
- Scaffolded a new React + Vite artifact (`artifacts/landing-page`) in the pnpm monorepo
- Configured to serve at the root path `/`

### 2. Frontend Built
Generated a complete, responsive single-page portfolio with the following sections:
- **Navbar** — sticky top navigation with anchor links (About, Skills, Experience, Contact) and GitHub/LinkedIn icon buttons
- **Hero** — name, title, animated badge, CTA buttons, and profile card
- **About** — personal bio, values, and interests list
- **Skills** — 8 core competencies displayed as animated icon cards (Collaboration, Analytical Thinking, Organization, Power BI, Microsoft Suite, Critical Thinking, Problem-Solving, Leadership)
- **Experience** — timeline layout with two entries: IT Intern (Power BI / KPI Dashboards) and Restaurant & Bar Manager
- **Contact** — social links to LinkedIn and GitHub

### 3. Headshot Added
- Copied user-provided headshot photo to `artifacts/landing-page/public/headshot.png`
- Updated `Hero.tsx` to display the real photo in a circular frame instead of the initials avatar

### 4. README.md Created
- Written at the repo root
- Includes: project overview, section table, tech stack table, file structure, local dev instructions, deployment notes (Azure + GitHub Actions), and social links

### 5. WORKING_NOTES.md Created
- This file

---

## Key Files Changed / Created

| File | Action |
|---|---|
| `artifacts/landing-page/src/App.tsx` | Updated with full routing and page structure |
| `artifacts/landing-page/src/index.css` | Replaced placeholder red values with a clean warm professional color palette |
| `artifacts/landing-page/src/pages/Home.tsx` | New — composes all sections |
| `artifacts/landing-page/src/components/layout/Navbar.tsx` | New — sticky nav bar |
| `artifacts/landing-page/src/components/sections/Hero.tsx` | New — hero section with headshot |
| `artifacts/landing-page/src/components/sections/About.tsx` | New — about / bio section |
| `artifacts/landing-page/src/components/sections/Skills.tsx` | New — competencies grid |
| `artifacts/landing-page/src/components/sections/Experience.tsx` | New — timeline experience |
| `artifacts/landing-page/src/components/sections/Contact.tsx` | New — contact / social links |
| `artifacts/landing-page/public/headshot.png` | New — profile photo |
| `README.md` | New — repo documentation |

---

## Dependencies Added
- `framer-motion` — scroll-triggered animations and section reveals
- `clsx` + `tailwind-merge` — conditional className utilities

---

## Personal Details Used
| Field | Value |
|---|---|
| Name | Jordan Griffith |
| Role | Business Analytics & Information Systems Student |
| University | University of Iowa (4th year) |
| LinkedIn | https://www.linkedin.com/in/jordan-griffith1 |
| GitHub | https://github.com/jordan-griffith |

---

## Known TODOs / Next Steps
- [ ] Update the `[View on Azure](#)` placeholder link in `README.md` once the Azure domain is live
- [ ] Add a real company name to the IT Intern experience entry (currently listed as "Confidential")
- [ ] Upload/add a resume PDF to the site if desired (link in Contact or Hero section)
- [ ] Push code to GitHub and verify the GitHub Actions deployment workflow succeeds
- [ ] Review the live Azure URL to confirm everything looks correct in production

---

## How to Run Locally
```bash
pnpm install
pnpm --filter @workspace/landing-page run dev
```
